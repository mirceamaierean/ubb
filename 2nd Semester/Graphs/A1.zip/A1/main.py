from ui import UI

ui = UI()

ui.run()
