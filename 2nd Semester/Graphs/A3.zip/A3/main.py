# pdoc ./ui.py ./service.py ./graph.py --logo http://www.cs.ubbcluj.ro/wp-content/themes/CSUBB/images/logo.png -o./docs
from ui import UI

ui = UI()

ui.run()
